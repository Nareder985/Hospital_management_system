package com.project.hospital_managemnet_system_E4.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.hospital_managemnet_system_E4.dto.BranchHead;

public interface BranchHeadRepo extends JpaRepository<BranchHead, Integer> {

}
