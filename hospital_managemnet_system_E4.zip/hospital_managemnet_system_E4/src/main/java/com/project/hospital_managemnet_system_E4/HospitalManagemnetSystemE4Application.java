package com.project.hospital_managemnet_system_E4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalManagemnetSystemE4Application {

	public static void main(String[] args) {
		SpringApplication.run(HospitalManagemnetSystemE4Application.class, args);
	}

}
